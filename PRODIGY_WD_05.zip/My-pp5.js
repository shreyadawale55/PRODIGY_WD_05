const apiKey = "YOUR_API_KEY"; // Replace with your OpenWeather API key

// Function to fetch weather based on city name input
async function fetchWeather() {
    const location = document.getElementById("locationInput").value;
    if (location) {
        getWeatherData(`q=${location}`);
    } else {
        alert("Please enter a location.");
    }
}

// Function to get weather data based on coordinates or city name
async function getWeatherData(query) {
    try {
        const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?${query}&appid=${apiKey}&units=metric`);
        const data = await response.json();

        if (data.cod === 200) {
            displayWeather(data);
        } else {
            alert("City not found. Please try again.");
        }
    } catch (error) {
        console.error("Error fetching weather data:", error);
        alert("Unable to retrieve weather data.");
    }
}

// Function to display the weather data on the page
function displayWeather(data) {
    document.getElementById("cityName").textContent = `${data.name}, ${data.sys.country}`;
    document.getElementById("temperature").textContent = `Temperature: ${data.main.temp} °C`;
    document.getElementById("description").textContent = `Conditions: ${data.weather[0].description}`;
    document.getElementById("humidity").textContent = `Humidity: ${data.main.humidity} %`;
    document.getElementById("windSpeed").textContent = `Wind Speed: ${data.wind.speed} m/s`;
}

// Function to get the user's location and fetch weather data
function fetchWeatherByLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(position => {
            const {
                latitude,
                longitude
            } = position.coords;
            getWeatherData(`lat=${latitude}&lon=${longitude}`);
        }, () => {
            alert("Unable to retrieve your location.");
        });
    } else {
        alert("Geolocation is not supported by your browser.");
    }
}

// Automatically fetch weather data for the user's location on page load
window.onload = fetchWeatherByLocation;